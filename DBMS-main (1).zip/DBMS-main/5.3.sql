SELECT * FROM StudentsF WHERE StudentID = 102;    -- Using primary index
SELECT * FROM StudentsF WHERE LastName = 'Doe';   -- Using secondary index
