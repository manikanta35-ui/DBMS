INSERT INTO StudentsF VALUES(101, 'John', 'Doe', TO_DATE('15-Aug-2025', 'DDMon-YYYY'));
INSERT INTO StudentsF VALUES(102, 'Jane', 'Smith', TO_DATE('16-Aug-2025', 'DDMon-YYYY'));
INSERT INTO StudentsF VALUES(103, 'Ravi', 'Kumar', TO_DATE('25-Oct-2025', 'DDMon-YYYY'));
