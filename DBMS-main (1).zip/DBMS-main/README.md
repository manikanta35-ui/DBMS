# DBMS
SQL Queries
